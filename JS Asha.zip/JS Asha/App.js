function Display_todos() {
    var List = new Array;

    var todos_str = localStorage.getItem('todo');
    if (todos_str !== null) {
        List = JSON.parse(todos_str);

    }
    return List;
}


function Delete() {

    var id = this.getAttribute('id');

    var List = Display_todos();

    List.splice(id, 1);

    localStorage.setItem('todo', JSON.stringify(List));

    Display();

    return false;
}


// function strike() {
//     var List = document.getElementById("List");
//     for (var i in List)
//         List[i].style.textDecoration = 'line-through'

// }



function done() {
    var List = document.querySelector('ul');

    List.addEventListener('click', function (ev) {
        if (ev.target.tagName === 'LI') {
            ev.target.classList.toggle('checked');
        }
    }, false);
}

function add() {
    var Todoinput = document.getElementById('Todoinput').value;
    var List = Display_todos();
    List.push(Todoinput);
    localStorage.setItem('todo', JSON.stringify(List));
    Display();
    return false;


}
function Display() {

    var List = Display_todos();

    var html = '<ul >';

    for (var i = 0; i < List.length; i++) {

        html += '<li class="Tstyle">' + List[i] + '<button class = "Delete" id="' + i + '"><i class ="fas fa-trash"></i></button><button onclick="done()"  id="' + i + '" ><i class ="fas fa-check"></i></button></li>';
    };

    html += '</ul>';
    document.getElementById('List').innerHTML = html;

    var buttons = document.getElementsByClassName('Delete');

    for (var i = 0; i < buttons.length; i++) {

        buttons[i].addEventListener('click', Delete);
    };

}
function filterTodo(e) {
    const todos = List.childNodes;
    todos.forEach(function (todo) {
        switch (e.target.value) {
            case "all":
                todo.style.display = "flex";
                break;
            case "checked":
                if (todo.classList.contains("checked")) {
                    todo.style.display = "flex";
                } else {
                    todo.style.display = "none";
                }
                break;
            case "unchecked":
                if (!todo.classList.contains("checked")) {
                    todo.style.display = "flex";
                } else {
                    todo.style.display = "none";
                }
                break;
        }
    });
}

document.getElementById('add').addEventListener('click', add);
Display();